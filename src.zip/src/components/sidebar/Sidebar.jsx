import React, { useEffect, useState } from 'react';
import { Button } from 'react-bootstrap';
import './Sidebar.css';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { obtenerConsolidacionCliente, obtenerContratos, obtenerPaginas } from '../administrador/gestores/apisUsuarios';
import { updateContratoConFacturacionAbierta, updatePaginasDelUsuario } from '../../redux/formularioSlice';
import { useDispatch } from 'react-redux';
import './SidebarMobile.css';

const Sidebar = ({ estadoActual }) => {
  const esEditor = useSelector((state) => state.formulario.es_editor);
  const esContratoConFacturacionAbierta = useSelector((state) => state.formulario.contratoConFacturacionAbierta);
  const cliente = useSelector((state) => state.formulario.cliente);
  const PerfilUsuario = useSelector((state) => state.formulario.usuario.perfil);
  const TOKEN = useSelector((state) => state.formulario.token);
  const id_cliente = useSelector((state) => state.formulario.id_cliente);
  const [paginasDelPerfil, setPaginasPerfil]= useState([]);
  const [respuestaCreditos, setRespuestaCreditos] = useState(null);
  const dispatch = useDispatch();

  useEffect(() => {
    if (!PerfilUsuario) return;

    const cargarPaginas = async () => {
      try {
        const res = await obtenerPaginas(TOKEN, PerfilUsuario);
        setPaginasPerfil(res);
        dispatch(updatePaginasDelUsuario(res));
      } catch (err) {
        console.error(err);
      }
    };
    cargarPaginas();
  }, [PerfilUsuario]);

  useEffect(() => {
    if (!id_cliente) return;
    const cargarCredito = async () => {
      try {
        const res = await obtenerConsolidacionCliente(TOKEN, id_cliente);
        setRespuestaCreditos(res);
      } catch (err) {
        console.error(err);
      }
    };
    const tieneContratoConFacturacionAbierta = async () => {
      try {
        const contratos = await obtenerContratos(TOKEN);
        const contratoAbierto = contratos.find(contrato => 
        contrato.id_cliente === id_cliente && contrato.abierto === 'SI');
        console.log('Contrato', contratoAbierto);
        dispatch(updateContratoConFacturacionAbierta(contratoAbierto ? true : false));
      } catch (err) {
        console.error(err);
      }
    };
    tieneContratoConFacturacionAbierta();
    cargarCredito();
  }, [id_cliente]);
  const location = useLocation();

  estadoActual = location.pathname.split('/')[1] || 'dashboard'; // Obtiene el estado actual desde la URL
  const [isOpen, setIsOpen] = useState(true);
  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const navigate = useNavigate();

  const handleClickBotonSidebar = (url) => {
    navigate(`/${url}`);
    isOpen && toggleSidebar();
  };

  const renderSidebarButton = (estado, url, icono, texto, iconoBootstrap) => (
    <li
      className={`${
        estadoActual === estado ? 'boton_sidebar_clickeado' : 'boton_sidebar_Noclickeado'
      } ${isOpen ? 'openBoton' : 'closedBoton'}`}
    >
      <Button className="botonSidebar" variant="none" onClick={() => handleClickBotonSidebar(url)}>
        <i class={`fs-4 mb-4 ${iconoBootstrap}`} style={{color: '#3e4658ff', marginRight: '5px', bottom: '10px'}}></i>
        <span className={`descripcion_boton ${isOpen ? 'open' : 'closed'}`}>{texto}</span>
      </Button>
    </li>
  );

  const obtenerCreditoDisponible = (respuestaCreditos) => {
    const creditoTotal = respuestaCreditos?.credito?.reduce(
    (acc, item) => acc + Number(item.monto_mensual),
    0
  ) ?? 0;

  const consumoTotal = respuestaCreditos?.consumo?.reduce(
    (acc, item) =>
      acc + Number(item.monto_dv360 || 0) + Number(item.monto_meta || 0),
    0
  ) ?? 0;

  const totalFormateado = (creditoTotal - consumoTotal).toLocaleString('es-AR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
    })
    return totalFormateado;
  }

  return (
    <>
      <div className={`sidebar no-print ${isOpen ? 'open' : 'closed'}`}>
        <div className="flex-grow-1">
          {isOpen ? (
            <img
              src="/images/logoNdNegroNaranja.png"
              alt="Logo grande"
              className="img-fluid"
              id="logo-nd-sidebar"
            />
          ) : (
            <img
              src="/images/logoNdNegroNaranjaMini.png"
              alt="Logo miniatura"
              className="img-fluid"
              id="logo-nd-miniatura"
              style={{ width: '50px !important' }}
            />
          )}

          {!isOpen && (
            <div className='logo-nd-mobile'>
              <img src="/images/logoNdNegroNaranja.png" alt="Logo Noticias" className="img-fluid d-block d-md-none logo-nd" />
            </div>
          )}

          <Button className="sidebar-toggle" variant="none" onClick={toggleSidebar}>
            {isOpen ? (
              <div className='logo-sidebar-mobile'>
                <img src="/images/sidebar_left_bot.png" alt="Cerrar sidebar" className="img-fluid d-none d-md-block" />
                <img src="/images/logo-menu-sidebar.png" alt="Cerrar sidebar mobile" className="img-fluid d-block d-md-none" />
              </div>
            ) : (
              <div className='logo-sidebar-mobile'>
                <img src="/images/sidebar_right_bot.png" alt="Abrir sidebar" className="img-fluid d-none d-md-block" />
                <img src="/images/logo-menu-sidebar.png" alt="Abrir sidebar mobile" className="img-fluid d-block d-md-none" />
              </div>
            )}
          </Button>

          <ul className="list-group list-group-flush no-border list-unstyled">
            {cliente &&
              renderSidebarButton(
                'dashboard',
                'dashboard',
                '/images/barchar_icon.png',
                'Dashboard',
                'bi bi-bar-chart-fill'
              )}  
            {esEditor === false
              ? renderSidebarButton('notas', 'notas', '/images/notas_icon.png', 'Notas', 'bi bi-stack')
              : renderSidebarButton(
                  'notasEditorial',
                  'notasEditorial',
                  '/images/notas_icon.png',
                  'Notas',
                  'bi bi-stack'
                )}
            {renderSidebarButton(
              'autoEntrevistas',
              'autoEntrevistas',
              '/images/auto_entrevistas_icon.png',
              'Auto-entrevistas',
              'bi bi-mic-fill'
            )}
            {PerfilUsuario == '1' && renderSidebarButton(
              'Administrador',
              'administrador',
              '/images/auto_entrevistas_icon.png',
              'Administración',
              'bi bi-gear-fill'
            )}
            {paginasDelPerfil.find((pagina) => pagina.nombre == "Distribucion" || pagina.nombre == "Monitor Distribucion" ) && renderSidebarButton(
              'distribucion',
              'distribucion',
              '/images/auto_entrevistas_icon.png',
              'Distribución',
              'bi bi-clipboard2-check-fill'
            )}
            
            {paginasDelPerfil.find((pagina) => pagina.nombre == "Comercial" ) && renderSidebarButton(
              'comercial',
              'comercial',
              '/images/auto_entrevistas_icon.png',
              'Comercial',
              'bi bi-bag-fill'
            )}
            <ul className="list-group list-unstyled botones_inferiories">
              {(respuestaCreditos && isOpen && esContratoConFacturacionAbierta) && (
                <>
                <h3 style={{marginTop: '0px'}}>credito:</h3>
                <h3 style={{ marginTop: '0px' }}>
                  ${' '}
                  {obtenerCreditoDisponible(respuestaCreditos)}
                </h3>
                <h3 style={{marginTop: '0px'}}><a target="_blank" href={`https://noticiasd.mitiendanube.com/autogestion/?clid=${id_cliente}`} style={{textDecoration: 'none'}}> 
                recargar credito </a>
                </h3>
                </>
              )}
              {renderSidebarButton(
                'soporte-y-ayuda',
                'soporte-y-ayuda',
                '/images/ayuda_icon.png',
                'Ayuda y soporte',
                'bi bi-headset'
              )}
              {renderSidebarButton(
                'mi-perfil',
                'mi-perfil',
                '',
                'Mi perfil',
                'bi bi-person-fill'
              )}
            </ul>
          </ul>
        </div>
      </div>
    </>
  );
};

export default Sidebar;