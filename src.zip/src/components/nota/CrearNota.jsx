import React, { useEffect, useRef, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import { Button, Modal } from 'react-bootstrap';
import Cropper from 'cropperjs';
import 'cropperjs/dist/cropper.css';
import '../../App.css'
import '../../components/nota/nota_print.css'
import '../../components/nota/nota.css'
import '../Dashboard/Dashboard.css';
import "./nota.css";
import SubtituloNota from './componetesNota/SubtituloNota';
import ParrafoNota from './componetesNota/ParrafoNota';
import TituloNota from './componetesNota/TituloNota';
import { setTituloNota, setContenidoNota, setImagenPrincipal, setIdAtt, setCambiarEstadoActual } from '../../redux/crearNotaSlice';
import { useDispatch, useSelector } from 'react-redux';
import ImagenDeParrafo from './componetesNota/ImagenDeParrafo';
import { Link, Navigate } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import YoutubeNota from './componetesNota/YoutubeNota';
import Ubicacion from './componetesNota/Ubicacion';
import Embebido from './componetesNota/Embebidos';
import ImagenPrincipal from './componetesNota/ImagenPrincipal';
import CopeteNota from './componetesNota/Copete';
import { videos } from '../miPerfil/soporte';
import CardTutorial from '../miPerfil/CardTutorial';
import { comprimirImagen } from './componetesNota/ImagenPrincipal';
import BotonEnGenerarVistaPrevia from './Editorial/BotonEnGenerarVistaPrevia';
import EpigrafeImagenPpal from './Editorial/epigrafeImagenPpal';
import VideosDeParrafo from './componetesNota/VideosDeParrafo';
import { useContext } from "react";
import { ArchivoContext } from "../../context/archivoContext";
import GaleriaImagenes from './componetesNota/GaleriaImagenes';
import ArchivoPDFParrafo from './componetesNota/ArchivosPdfParrafo';
import { comprimirPDFaBase64 } from '../../utils/convertirPDFaBase64';
import CarruselEnNota from './componetesNota/CarruselEnNota';
import FormFranquicias from './componetesNota/FormFranquicias';
import ImagePickerModal from './componetesNota/ImagePickerModal';
import GuardarNotaCada10sg from './GuardarNotaCada10SG';
import BotonRegenerarDataConIa from './botonesIa/BotonRegenerarTextoConIa';
import { setContenidoDeNotaDeIa } from '../../redux/crearNotaSlice';


const CrearNota = () => {
    const idUsuario = useSelector((state) => state.formulario.usuario.id); 
    const dispatch = useDispatch();
    const [image, setImage] = useState(null);
    const navigate = useNavigate();
    const imagenppal = useSelector((state) => state.crearNota);
    const [cropper, setCropper] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const imageRef = useRef(null);
    const [showButtons, setShowButtons] = useState(false);
    const inputFileRef = useRef(null);
    const inputFileRefArchivoPDF = useRef(null);
    const [show, setShow] = useState(false);
    const TOKEN = useSelector((state) => state.formulario.token);
    const inputVideoRef = useRef(null);
    const { setArchivo } = useContext(ArchivoContext);
    const actual = useSelector((state) => state.crearNota);
    const [historial, setHistorial] = useState([]);
    const [futuros, setFuturos] = useState([]);
    const esEditor = useSelector((state) => state.formulario.es_editor);
    const contenidoNota = useSelector((state) => state.crearNota.contenidoNota);
    const numeroDeAtachmentAUsar= useSelector((state) => state.crearNota.numeroDeAtachment);

  // ⚠️ Esta ref indica si el cambio fue por undo/redo (entonces NO guardamos en historial)
  const saltoDeHistorial = useRef(false);

  // Clonar para evitar referencias compartidas
  const copiar = (obj) => JSON.parse(JSON.stringify(obj));

  // ✅ Escuchar cambios automáticos en "actual" (hechos por otros componentes)
  useEffect(() => {
  if (saltoDeHistorial.current) {
    saltoDeHistorial.current = false;
    return;
  }

  setHistorial((prev) => {
    const nuevoHistorial = [...prev, copiar(actual)];
    // Limitar a los últimos 20
    return nuevoHistorial.length > 20
      ? nuevoHistorial.slice(nuevoHistorial.length - 20)
      : nuevoHistorial;
  });

  setFuturos([]); // limpiar futuros si hubo un cambio nuevo
}, [actual]);

  const handleUndo = () => {
    if (historial.length === 0) return;

    const anterior = historial[historial.length - 1];
    setHistorial((prev) => prev.slice(0, -1));
    setFuturos((prev) => [copiar(actual), ...prev]);

    saltoDeHistorial.current = true;
    dispatch(setCambiarEstadoActual(copiar(anterior)));
  };

  const handleRedo = () => {
    if (futuros.length === 0) return;

    const siguiente = futuros[0];
    setFuturos((prev) => prev.slice(1));
    setHistorial((prev) => [...prev, copiar(actual)]);

    saltoDeHistorial.current = true;
    dispatch(setCambiarEstadoActual(copiar(siguiente)));
  };

    const toggleButtons = () => {
      setShowButtons(!showButtons);
    };

    const handleClickEnNota = () => {
        inputFileRef.current.click();
    };

    const handleClickEnArchivoPDF = () => {
        inputFileRefArchivoPDF.current.click();
    };

    const handleArchivoVideo = (e) => {
        setArchivo(e.target.files[0]);
        agregarContenido("video", "");
    };

    const handleFileChangeEnNota = (event) => {
        const file = event.target.files[0];
        if (file) {
            agregarContenido("imagen", file);
        }
    };
    const handleFileChangeArchivoNota = (event) => {
        const file = event.target.files[0];
        if(file){
            agregarContenido('archivoPDF', file)
        }
    }
    const agregarImagenDeElCliente = () => {
        setShow(true)
    }
    useEffect(() => {
        const timestamp = Date.now(); // Obtiene el timestamp actual
        dispatch(setIdAtt(idUsuario + "_" + timestamp));
    }, [idUsuario]);

    const agregarContenido = async (tipo, contenido = "") => {
        if (tipo === "imagen") {
            try {
                const compressedBase64 = await comprimirImagen(contenido, 0.8, 1600); 
                dispatch(setContenidoNota([tipo, compressedBase64])); // Almacena la imagen comprimida en base64
            } catch (error) {
                console.error("Error al comprimir la imagen:", error);
            }
        } else if((tipo === "video")){
            dispatch(setContenidoNota([tipo, contenido]));

        } else if((tipo === "archivoPDF")){
            const archivoPDFEnBase64 = await comprimirPDFaBase64(contenido)
            dispatch(setContenidoNota([tipo, archivoPDFEnBase64]));
        }else
            {
            // Si no es una imagen, solo almacenamos el contenido normalmente
            dispatch(setContenidoNota([tipo, contenido]));
        }
    };

    useEffect(() => {
        if (imageRef.current && image) {
            if (cropper) {
                cropper.destroy();
            }
            const newCropper = new Cropper(imageRef.current, {
                aspectRatio: NaN,
                viewMode: 3,
            });
            setCropper(newCropper);
        }
    }, [image]);

    const handleCrop = () => {
        if (cropper) {
            const canvas = cropper.getCroppedCanvas();
            dispatch(setImagenPrincipal(canvas.toDataURL()));
            setShowModal(false); // Cierra el modal después de recortar
            setImage(null); // Oculta la imagen original
            cropper.destroy(); // Destruye el cropper
        }
    };


  


    return (

                <div className="content flex-grow-1 crearNotaGlobal">
                    <GuardarNotaCada10sg nota={actual} />
                    <div className='row'>
                        <div className='col'>
                            <h4 id="nota">
                                <nav aria-label="breadcrumb">
                                    <ol className="breadcrumb">
                                        {esEditor ?
                                            <li className="breadcrumb-item"><Link to="/notasEditorial" className='breadcrumb-item'>{'< '} Notas</Link></li>
                                            :
                                            <li className="breadcrumb-item"><Link to="/notas" className='breadcrumb-item'>{'< '} Notas</Link></li>
                                        }
                                        <li className="breadcrumb-item blackActive" aria-current="page">Crear Nota</li>
                                    </ol>
                                </nav>
                            </h4>
                        </div>
                        <div className='col'>
                            <BotonEnGenerarVistaPrevia status= {'Preview'}/>
                        </div>
                        <div className='col-auto'>
                            <Button onClick={() => navigate('/publicarNota')} id="botonPublicar" variant="none">
                                <img src="/images/send.png" alt="Icono 1" className="icon me-2 icono_tusNotas" />{" Publicar"}
                            </Button>
                        </div>
                    </div>
                    <div className='row'>
                        <div className='col mt-0'>
                            <h3 className='headerCrearNota'>Crear nota</h3>
                        </div>
                    </div>
                    {/* SECCION NOTA */}
                    <div className='row notaTutorial'>
                        <div className='col-8 columnaNota'>
                            <ImagenPrincipal />
                            <EpigrafeImagenPpal />
                            <div className='row'>
                                <TituloNota />
                                <CopeteNota />

                                {contenidoNota &&
                                    contenidoNota.map((contenido, index) => {
                                        const componentes = {
                                        subtitulo: SubtituloNota,
                                        parrafo: ParrafoNota,
                                        imagen: ImagenDeParrafo,
                                        videoYoutube: YoutubeNota,
                                        ubicacion: Ubicacion,
                                        embebido: Embebido,
                                        video: VideosDeParrafo,
                                        archivoPDF: ArchivoPDFParrafo,
                                        carousel: CarruselEnNota,
                                        formFranquicias: FormFranquicias,
                                        };

                                    const Componente = componentes[contenido[0]]; // Obtiene el componente correspondiente

                                    return Componente ? <Componente key={index} indice={index} numeroDeAtachmentAUsar = {numeroDeAtachmentAUsar} /> : null; // Renderiza el componente si existe
                                })}
                                {actual.es_ia === '1' &&
                                <BotonRegenerarDataConIa token = {TOKEN} term_id={actual.term_id} nombreBoton={'Regenerar contenido'} 
                                    action = {setContenidoDeNotaDeIa} endpoint={'app_obtener_texto_ia'}/>
                                }
                                <ImagePickerModal
                                    isOpen={show}
                                    onClose={() => setShow(false)}
                                    fetchUrl="https://panel.serviciosd.com/app_imagenes_por_cliente" // URL del endpoint que devuelve URLs
                                />

                                {/* BOTONERA AGREGAR CONTENIDO */}
                                <div className="containerButton">
                                    <button onClick={toggleButtons} className={`botones-nota ${showButtons ? 'boton-plus' : ''}`}>
                                        {showButtons ? <img src="images/plus-circle-x.png" alt="" /> : <img src="images/plus-circle-+.png" alt="" />}
                                    </button>

                                    {showButtons && (
                                        <div className="buttons-container">
                                            <button onClick={() => agregarContenido("parrafo")} className="botones-nota" title='Párrafo'>
                                                <i className="bi bi-type rounded-circle border border-dark p-2"></i>
                                            </button>
                                            <button onClick={handleClickEnNota} className="botones-nota" title="Imagen">
                                                <i className="bi bi-image rounded-circle border border-dark p-2"></i>

                                            </button>
        
                                            <input
                                                type="file"
                                                ref={inputFileRef}
                                                style={{ display: 'none' }}
                                                onChange={handleFileChangeEnNota}
                                                accept="image/*"  // Acepta solo archivos de imagen
                                            />
                                            {/* <button onClick={() => agregarContenido("ubicacion")} className="botones-nota" title="Ubicación">
                                                <i className="bi bi-geo-alt rounded-circle border border-dark p-2"></i>
                                            </button> */}
                                            <button onClick={() => agregarContenido("embebido")} className="botones-nota" title="Embebidos">
                                                <i className="bi bi-code-slash rounded-circle border border-dark p-2"></i>
                                            </button>
                                            <button onClick={() => inputVideoRef.current.click()} className="botones-nota" title="Video MP4">
                                                <i className="bi bi-filetype-mp4 rounded-circle border border-dark p-2"></i>
                                            </button>
                                            <input
                                                type="file"
                                                ref={inputVideoRef}
                                                style={{ display: 'none' }}
                                                onChange={handleArchivoVideo}
                                                accept="video/mp4"
                                            />

                                            {/*       BOTON DE ARCHIVOS PDF         */}
                                            <button onClick={handleClickEnArchivoPDF} className="botones-nota" title="Archivo PDF">
                                                <i className="bi bi-filetype-pdf rounded-circle border border-dark p-2"></i>
                                            </button>
        
                                            <input
                                                type="file"
                                                ref={inputFileRefArchivoPDF}
                                                style={{ display: 'none' }}
                                                onChange={handleFileChangeArchivoNota}
                                                accept=".pdf"  // Acepta solo archivos pdf
                                            />
                                            <button onClick={handleUndo} className="botones-nota" title="deshacer">
                                                <i className="bi bi-arrow-left rounded-circle border border-dark p-2"></i>
                                            </button>
                                            <button onClick={handleRedo} className="botones-nota" title="rehacer">
                                                <i className="bi bi-arrow-right rounded-circle border border-dark p-2"></i>
                                            </button>
                                            <button onClick={agregarImagenDeElCliente} className="botones-nota" title="rehacer">
                                                <i className="bi bi-collection rounded-circle border border-dark p-2"></i>
                                            </button>
                                            {esEditor && (
                                                <button onClick={() => agregarContenido("formFranquicias")} className="botones-nota" title="formulario">
                                                    <i className="bi bi-journal rounded-circle border border-dark p-2"></i>
                                                </button>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Seccion columna izquierda del tutorial */}
                        <div className='col-4' style={{ paddingRight: "30px", display: "flex", flexDirection: "column", gap: "30px" }}>
                            {!imagenppal ? <CardTutorial title = {videos.portada.title} description = {videos.portada.description} src = {videos.portada.src} /> : 
                            <CardTutorial title = {videos.fotoCuerpoNota.title} description = {videos.fotoCuerpoNota.description} src = {videos.fotoCuerpoNota.src}/>}
                            <CardTutorial title = {videos.tituloYBajada.title} description = {videos.tituloYBajada.description} src = {videos.tituloYBajada.src}/>
                            <CardTutorial title = {videos.embebidos.title} description = {videos.embebidos.description} src = {videos.embebidos.src}/>

                        </div>
                        {/* fin seccion columna izquierda */}
                    </div>

                    {/* Modal para la imagen */}
                    <Modal show={showModal} onHide={() => setShowModal(false)} centered backdrop="static" dialogClassName="custom-modal">
                        <Modal.Header className='modalHeader'>
                            <Modal.Title>
                                <div className='tituloModal'>Selecciona la posicion de la imagen</div>
                            </Modal.Title>
                        </Modal.Header>
                        <Modal.Body className='modalBody'>
                            <div className='subtitulo-modal'>Selecciona el recorte que se utilizara para los canales donde la imagen deba ser adaptada</div>
                            <div className='custom_image_modal'>
                                {image && (
                                    <img
                                        ref={imageRef}
                                        src={image}
                                        alt="Imagen seleccionada"
                                        className='custom_image_modal'
                                    />
                                )}
                            </div>
                        </Modal.Body>
                        <Modal.Footer className='modalFooter'>
                            <div className='row rowModalFooter'>
                                <div className='col text-align-center'>
                                    <Button variant="none" onClick={() => setShowModal(false)} className='botonModalVolver'>
                                        Volver
                                    </Button>
                                </div>
                                <div className='col text-align-center'>
                                    <Button variant="none" onClick={handleCrop} className='botonModalContinuar'>
                                        Continuar
                                    </Button>
                                </div>
                            </div>
                        </Modal.Footer>
                    </Modal>

                </div>
    );
};

export default CrearNota;