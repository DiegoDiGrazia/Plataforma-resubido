import axios from "axios";

const fetchData = async (url, token, extraParams = {}) => {
  try {
    const formData = new FormData();
    formData.append("token", token);

    Object.entries(extraParams).forEach(([key, value]) => {
      if (value !== undefined && value !== null){
        if (Array.isArray(value)) {
          value.forEach(item => formData.append(`${key}[]`, item)); // si es un array, a cada elemento lo junta con []
        } else {
          formData.append(key, value);
        }
      }
    });

    const response = await axios.post(url, formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });

    return response.data.item || [];
  } catch (err) {
    console.error(`Error al obtener datos de ${url}:`, err);
    return [];
  }
};

const fetchDataDevolviendoMensaje = async (url, token, extraParams = {}) => {
  try {
    const formData = new FormData();
    formData.append("token", token);

    Object.entries(extraParams).forEach(([key, value]) => {
      formData.append(key, value);
    });

    const response = await axios.post(url, formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });

    return response.data.message || '';
  } catch (err) {
    console.error(`Error al obtener datos de ${url}:`, err);
    return [];
  }
};

export const obtenerGeo = async () => {
  try {
    const response = await axios.get(`https://api.noticiasd.com/app_obtener_geo`);
    return response.data.item.geo;
  } catch (error) {
    console.error('Error en obtener geo:', error);
    throw error;
  }
};

export const obtenerUsuarios = (token) =>
  fetchData("https://panel.serviciosd.com/app_obtener_usuarios_abm", token);

export const obtenerComisionistas = (token) =>
  fetchData("https://panel.serviciosd.com/app_get_comisionistas", token);

export const obtenerClientes = (token) =>
  fetchData("https://panel.serviciosd.com/app_obtener_clientes", token, {
    cliente: "",
  });

export const obtenerPerfiles = (token) =>
  fetchData("https://panel.serviciosd.com/app_obtener_perfiles", token);

export const obtenerPaginas = (token, id_perfil) =>
  fetchData("https://panel.serviciosd.com/app_obtener_paginas", token, {
    id_perfil,
  });

  export const obtenerContratos = (token) =>
  fetchData("https://panel.serviciosd.com/app_get_contratos", token, {
  });

export const eliminarPaginaDelPerfil = (token, id_perfil, id_pagina) =>
  fetchData("https://panel.serviciosd.com/app_acceso_eliminar", token, {
    id_perfil, id_pagina
  });

export const agregarPaginaDelPerfil = (token, id_perfil, id_pagina) =>
  fetchData("https://panel.serviciosd.com/app_acceso_agregar", token, {
    id_perfil, id_pagina
});

export const obtenerNotasDeGeneraciones = (token, cliente = '', desde, hasta, 
                                            categoria, limit, offset, titulo, pais, vencimiento_desde = '', vencimiento_hasta = '') =>
  fetchData("https://panel.serviciosd.com/app_obtener_noticias_abm", token, {
    cliente, desde, hasta, categoria, limit, offset, titulo, pais, vencimiento_desde, vencimiento_hasta
});


export const obtenerPlanesMarketing = (token, desde, hasta) =>
  fetchData("https://panel.serviciosd.com/app_obtener_planes_marketing", token, {
    desde, hasta
});

//guardar_posicion_iframes
export const guardar_dato_en_banner_data = (token, id, datos) =>
  fetchData("https://reporte.noticiasd.com/api/guardar_posicion_creativos", token, {
    id, datos
});

export const obtenerPoblacion = (token, division, id) =>
  fetchData("https://panel.serviciosd.com/app_get_estimacion", token, {
    division, id
});

export const obtenerPrecioUsuario = (token, division, id, id_cliente, fecha=null) =>
  fetchData("https://panel.serviciosd.com/app_get_precio_usuario", token, {
    division, id, id_cliente, fecha
});
export const obtenerConsolidacionCliente = (token, id_cliente) =>
  fetchData("https://panel.serviciosd.com/app_get_consolidacion_cliente", token, {
    id_cliente
  });

  export const obtenerArchivosDelContrato = (token, id) =>
  fetchData("https://panel.serviciosd.com/app_obtener_contratos_archivos", token, {
    id
  });

  export const obtenerComentariosDelContrato = (token, id) =>
  fetchData("https://panel.serviciosd.com/app_obtener_contratos_comentarios", token, {
    id
  });

  export const obtenerVideosYoutube = (token, desde, hasta, limite, desde_limite) =>
  fetchData("https://panel.serviciosd.com/app_obtener_videos_noticias", token, {
    desde, hasta, limite, desde_limite
  });
  export const guardarVideoYoutube = (token, video, fecha_vencimiento,id) =>
    fetchData("https://panel.serviciosd.com/app_subir_video_nota", token, {
      video, fecha_vencimiento, id
  });

  export const guardarComentarioDeUnContrato = (token, id, comentarios_in, id_usuario) =>
  fetchData("https://panel.serviciosd.com/app_comentario_edit", token, {
    id, comentarios_in, id_usuario
  });
  export const guardarArchivoDeUnContrato = (token, id_contrato_archivo, id_usuario, archivo) =>
  fetchData("https://panel.serviciosd.com/app_contrato_archivo_edit", token, {
    id_contrato_archivo, id_usuario, archivo
  });

  export const setComprarDistribucion = (token, division, id, id_usuario, usuarios, id_cliente, id_noti, monto_dv360=null, monto_meta= null, fecha_fin, fecha_inicio, comentarios) =>
    fetchData("https://panel.serviciosd.com/app_set_comprar_distribución", token, {
      division, id, id_usuario, usuarios, id_cliente, id_noti, monto_dv360, monto_meta, fecha_fin, fecha_inicio, comentarios
  });

  export const editar_o_crear_cliente = (token, id, name,   
      authors, provincia_cliente, municipio_cliente, pais_cliente, tipo_cliente, juridisccion_cliente, muestra_consumo, id_plan) =>
      console.log('token', token, 'id', id, 'name', name, 
      'authors', authors, 'provincia_cliente', provincia_cliente, 'municipio_cliente', municipio_cliente, 
      'pais_cliente', pais_cliente, 'tipo_cliente', tipo_cliente, 'juridisccion_cliente', juridisccion_cliente, 
      'muestra_consumo', muestra_consumo, 'id_plan', id_plan);

export const obtenerTextoRegeneradoConIa = (token, term_id, endpoint) =>
  fetchDataDevolviendoMensaje("https://panel.serviciosd.com/" + endpoint, token, {
    term_id
});

export const obtenerFacturas = (token, desde, hasta) =>
  fetchData("https://panel.serviciosd.com/app_obtener_facturas", token, {desde, hasta});

export const editarFactura = (token, id_factura, numero, estado, mes, fecha_pago) =>
  fetchData("https://panel.serviciosd.com/app_factura_edit", token, {id_factura, numero, estado, mes, fecha_pago});

export const unificarFacturas = (token, id_factura, id_factura_original) =>
  fetchData("https://panel.serviciosd.com/app_facturas_unificar", token, {id_factura, id_factura_original});

export const dividirFactura = (token, id_factura, cantidad, mes) =>
  fetchData("https://panel.serviciosd.com/app_facturas_dividir", token, {id_factura, cantidad, mes});

export const cargarFacturaAbierta = (token, numero, estado, mes, id_contrato , monto_mensual, fecha_pago) =>
  fetchData("https://panel.serviciosd.com/app_factura_abierta_edit", token, {numero, estado, mes, id_contrato , monto_mensual, fecha_pago});

export const eliminarFacturaAbierta = (token, id) =>
  fetchData("https://panel.serviciosd.com/app_factura_abierta_eliminar", token, {id});

export const obtenerFacturasDeContrato = (token, id_contrato) =>
  fetchData("https://panel.serviciosd.com/app_obtener_facturas_contrato", token, {id_contrato});

export const obtenerArchivosDeContrato = (token, id) =>
  fetchData ("https://panel.serviciosd.com/app_obtener_contratos_archivos", token, {id});

export const obtenerResumenDashboardCliente = (token, cliente_id) =>
  fetchData ("https://panel.serviciosd.com/app_obtener_resume", token, {cliente_id});

export const obtenerResumenDashboardNota = (token, id_noti) =>
  fetchData ("https://panel.serviciosd.com/app_obtener_resume", token, {id_noti});

export const cargarArchivo = (token, id_usuario, archivo, id_contrato_archivo) =>
  fetchData("https://panel.serviciosd.com/app_contrato_archivo_edit", token, {
    id_usuario, archivo, id_contrato_archivo});

export const eliminarArchivo = (token, id, id_usuario) =>
  fetchData("https://panel.serviciosd.com/app_contrato_archivo_eliminar", token, {id, id_usuario});

export const obtenerComentariosDeContrato = (token, id) =>
  fetchData("https://panel.serviciosd.com/app_obtener_contratos_comentarios", token, {id});

export const agregarComentario = (token, id_usuario, comentarios_in, id) =>
  fetchData("https://panel.serviciosd.com/app_comentario_edit", token, {id_usuario, comentarios_in, id});

export const obtenerNotaCompletaConIa = (token, id, term_id) =>
  fetchData("https://panel.serviciosd.com/app_obtener_completo_ia", token, {id, term_id});

export const obtenerFuenteBot = (token, term_id) =>
  fetchData("https://panel.serviciosd.com/app_obtener_fuente_bot", token, {term_id});

export const obtenerSitiosPaises = (token, pais_id) =>
  fetchData("https://panel.serviciosd.com/app_obtener_m_sitios_paises", token, {pais_id});

export const obtenerSitiosProvincias = (token, provincia_id) =>
  fetchData("https://panel.serviciosd.com/app_obtener_m_sitios_provincias", token, {provincia_id});

export const agregarSitioPaises = (token, pais_id, sitio) =>
  fetchData("https://panel.serviciosd.com/app_agregar_m_sitios_paises", token, {pais_id, sitio});

export const agregarSitioProvincias = (token, provincia_id, sitio) =>
  fetchData("https://panel.serviciosd.com/app_agregar_m_sitios_provincias", token, {provincia_id, sitio});

export const eliminarSitiosPaises = (token, pais_id, id_sitio) =>
  fetchData("https://panel.serviciosd.com/app_eliminar_m_sitios_paises", token, {pais_id, id_sitio});

export const eliminarSitiosProvincias = (token, provincia_id, id_sitio) =>
  fetchData("https://panel.serviciosd.com/app_eliminar_m_sitios_provincias", token, {provincia_id, id_sitio});

export const editarSitio = (token, id, sitio, imagen) => 
fetchData ("https://panel.serviciosd.com/app_sitio_edit", token, {id, sitio, imagen});

export const validarToken = async (token) => {
    const formData = new FormData();
    formData.append("token", token);
    
    const response = await axios.post("https://panel.serviciosd.com/app_chequear_token", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    return response.data; 
};